@extends('layouts.page')

@section('content')
<div class="aboveTheFold">
    <h2>TURNING YOUR IDEAS INTO MAGNIFICENT VISUALS</h2>
    <div class="desktop">
        <section class="footer">
            <div class="bagi bagi-3">
                <div>#DoMagnificent</div>
            </div>
            <div class="bagi bagi-3">
                <pre>{!! $writings['footer 1'] !!}</pre>
            </div>
            <div class="bagi bagi-3">
                <pre>{!! $writings['footer 2'] !!}</pre>
            </div>
        </section>
    </div>
    <div class="mobile">
        <section class="footer">
            <div class="bagi bagi-2">
                <div class="lebar-90">
                    <div>#DoMagnificent</div>
                    <pre>{!! $writings['footer 1'] !!}</pre>
                </div>
            </div>
            <div class="bagi bagi-2 rata-kanan">
                <pre>{!! $writings['footer 2'] !!}</pre>
            </div>
        </section>
    </div>
</div>

<div class="tinggi-160"></div>
@include('partials/OurValue')

<div class="tinggi-160"></div>
<section class="portfolio">
    <h3>OUR WORK</h3>
    <div id="items">
        <div id="loadPortfolio"></div>
        
        <br />
        <div class="item"></div>
        <div class="item">
            <h4 class="pointer garis-bawah" id="loadMore" onclick="loadMore()">
                Load More
            </h4>
            <h4 class="pointer d-none garis-bawah" id="toPortfolio">
                <a href="{{ route('user.portfolio') }}">
                    All Work <div class="custicon ml-1" icon="external-link-white" size="20"></div>
                </a>
            </h4>
        </div>
    </div>
</section>

<div class="tinggi-160"></div>
<section class="service">
    <div class="bagi bagi-2">
        <h3>WHAT WE DO</h3>
        <p class="lebar-80">{{ $writings['service'] }}</p>
    </div>
    <div class="bagi bagi-2" id="items">
        @foreach ($categories as $category)
            <h3 class="mt-0">{{ $category->name }}</h3>
            @foreach ($category->services as $service)
                <div class="bagi bagi-4">
                    <div class="wrap">
                        <div class="containerList squarize" style="height: 150px;">
                            <div class="item">{{ $service->name }}</div>
                        </div>
                    </div>
                </div>
            @endforeach
            <a href="{{ route('user.service') }}">
                <div class="bagi bagi-4">
                    <div class="wrap">
                        <div class="containerList" style="height: 150px;">
                            <div class="item">SHOW MORE <br /> <i class="fas fa-external-link-alt"></i></div>
                        </div>
                    </div>
                </div>
            </a>
            <div class="tinggi-40"></div>
        @endforeach
    </div>
</section>

@include('./partials/CTA')
@include('./partials/Footer')

@endsection

@section('javascript')
<script>
    let toLoad = 5;
    let loadedDataId = [];

    const loadPortfolio = () => {
        let req = post("{{ route('api.portfolio.load') }}", {
            count: toLoad
        })
        .then(res => {
            let datas = res.datas;
            if (datas.length < toLoad) {
                console.log(datas);
                select("#loadMore").classList.add('d-none');
                select("#toPortfolio").classList.remove('d-none');
            }
            datas.forEach(portfolio => {
                if (!inArray(portfolio.id, loadedDataId)) {
                    createElement({
                        el: "div",
                        attributes: [
                            ['class', 'portfolio-item']
                        ],
                        html: `<div class="bagi bagi-2 desktop">
        <div class="wrap ml-0">
            <a href="{{ route('user.portfolio.detail') }}/${portfolio.id}">
                <div class="cover squarize rectangle rounded" bg-image="{{ asset('storage/portfolio_images') }}/${portfolio.featured_image}"></div>
            </a>
        </div>
    </div>
    <div class="bagi bagi-2 desktop detail">
        <div class="ml-0 p-4">
            <a href="{{ route('user.portfolio.detail') }}/${portfolio.id}">
                <h3>${portfolio.title}
                    <div class="custicon ke-kanan mt-1" size="30" icon="external-link-white"></div>
                </h3>
                <p>${portfolio.description}</p>
            </a>
            <div id="categoriesArea${portfolio.id}"></div>
        </div>
    </div>
    <br />
    <hr size="1" color="#fff" />`,
                        createTo: '#loadPortfolio'
                    });

                    let categories = portfolio.categories.split(",");
                    categories.forEach(category => {
                        createElement({
                            el: 'a',
                            attributes: [
                                ['href', `{{ route('user.portfolio') }}?category=${category}`]
                            ],
                            html: `<div class="category-item">${category}</div>`,
                            createTo: `#categoriesArea${portfolio.id}`
                        });
                    });
                }
                loadedDataId.push(portfolio.id);
            });
            bindDivWithImage();
            squarize();
            custicon();
            toggleLightMode(1);
        });
    }
    loadPortfolio();

    const loadMore = () => {
        toLoad += 5;
        loadPortfolio();
    }
</script>
@endsection
