<div class="tinggi-160"></div>
<section class="cta rata-tengah">
    <a href="{{ route('user.service') }}">
        <button>Let's get to work</button>
    </a>
</section>