<nav class="main-menu">
    <div class="wrap">
        <ol>
            <a href="{{ route('user.index') }}">
                <li>HOME</li>
            </a>
            <a href="{{ route('user.about') }}">
                <li>ABOUT</li>
            </a>
            <a href="{{ route('user.portfolio') }}">
                <li>OUR WORK</li>
            </a>
            <a href="{{ route('user.service') }}">
                <li>WHAT WE DO</li>
            </a>
        </ol>
    </div>
</nav>