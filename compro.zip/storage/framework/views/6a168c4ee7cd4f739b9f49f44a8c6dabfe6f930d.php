<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(env('APP_NAME')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fa/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
</head>
<body>
    
<div class="content">
    <div class="logo">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
    </div>
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html><?php /**PATH /home/haloriyan/project/compro/resources/views/layouts/auth.blade.php ENDPATH**/ ?>