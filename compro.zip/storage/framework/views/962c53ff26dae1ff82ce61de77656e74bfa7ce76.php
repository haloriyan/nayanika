<?php $__env->startSection('head.dependencies'); ?>
<style>
    .aboveTheFold h2 {
        padding-bottom: 120px;
        border-bottom: 2px solid #fff;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="aboveTheFold rata-tengah">
    <h2>ABOUT US</h2>
</div>

<section class="rata-tengah">
    <div class="bagi lebar-70">
        <h3 style="margin-top: 0px" class="mb-2"><?php echo e($writings['tagline']); ?></h3>
        <p><?php echo e($writings['about']); ?></p>

        <button>
            #DOMagnificent
        </button>
    </div>
</section>

<div class="tinggi-60 border-top-2 mt-6"></div>

<?php echo $__env->make('./partials/OurValue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('./partials/CTA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('./partials/Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/about.blade.php ENDPATH**/ ?>