<div class="tinggi-160"></div>

<section class="footer">
    <?php if(isset($customContent)): ?>
        <div class="customContent">
            <?php echo $customContent; ?>

        </div>
    <?php endif; ?>
    <div class="desktop">
        <div class="bagi bagi-3 footer_a">
            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>">
            </div>
            <div><i class="fas fa-copyright"></i> <?php echo e(date('Y')); ?> NAYANIKA WORK</div>
        </div>
        <div class="bagi bagi-3 footer_b">
            <pre><?php echo $writings['footer 1']; ?></pre>
        </div>
        <div class="bagi bagi-3 footer_c">
            <pre><?php echo $writings['footer 2']; ?></pre>
        </div>
    </div>
    <div class="mobile">
        <div class="bagi bagi-2 footer_a">
            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>">
            </div>
            <div><i class="fas fa-copyright"></i> <?php echo e(date('Y')); ?> NAYANIKA WORK</div>
        </div>
        <div class="bagi bagi-2">
            <div class="footer_b">
                <pre><?php echo $writings['footer 1']; ?></pre>
            </div>
            <div class="footer_c">
                <pre><?php echo $writings['footer 2']; ?></pre>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/haloriyan/project/compro/resources/views///partials/Footer.blade.php ENDPATH**/ ?>