<?php $__env->startSection('title', "Profile"); ?>

<?php $__env->startSection('content'); ?>
<?php if($message != ""): ?>
    <div class="bg-hijau-transparan rounded p-2 mb-3">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>

<h2 class="mt-0">Informasi Dasar</h2>
<div class="bg-putih rounded bayangan-5 smallPadding">
    <div class="wrap">
        <form action="<?php echo e(route('admin.profile.update')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="mt-2">Nama :</div>
            <input type="text" class="box" name="name" value="<?php echo e($myData->name); ?>" required>
            <div class="mt-2">Email :</div>
            <input type="text" class="box" name="email" value="<?php echo e($myData->email); ?>" required>

            <button class="primer lebar-100 mt-3">Simpan Perubahan</button>
        </form>
    </div>
</div>

<h2>Ubah Password</h2>
<div class="bg-putih rounded bayangan-5 smallPadding">
    <div class="wrap">
        <form action="<?php echo e(route('admin.profile.updatePassword')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="mt-2">Buat Password Baru :</div>
            <input type="password" class="box" name="password" required>

            <div class="mt-1 teks-transparan">Anda akan logout setelah mengubah password</div>

            <button class="lebar-100 mt-3 primer">Simpan Perubahan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/admin/profile.blade.php ENDPATH**/ ?>