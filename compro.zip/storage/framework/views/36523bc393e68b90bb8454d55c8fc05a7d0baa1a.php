<nav class="main-menu">
    <div class="wrap">
        <ol>
            <a href="<?php echo e(route('user.index')); ?>">
                <li>HOME</li>
            </a>
            <a href="<?php echo e(route('user.about')); ?>">
                <li>ABOUT</li>
            </a>
            <a href="<?php echo e(route('user.portfolio')); ?>">
                <li>OUR WORK</li>
            </a>
            <a href="<?php echo e(route('user.service')); ?>">
                <li>WHAT WE DO</li>
            </a>
        </ol>
    </div>
</nav><?php /**PATH /home/haloriyan/project/compro/resources/views///partials/Menu.blade.php ENDPATH**/ ?>