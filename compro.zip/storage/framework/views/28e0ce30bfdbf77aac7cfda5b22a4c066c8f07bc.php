<?php $__env->startSection('title', "Copywriting"); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-putih rounded bayangan-5 smallPadding">
    <div class="wrap">
        <?php if($message != ""): ?>
            <div class="bg-hijau-transparan rounded p-2 mb-3">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.copywriting.update')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="code" value="<?php echo e($writing->item_code); ?>">
            <h2><?php echo e(ucwords($writing->item_code)); ?></h2>
            <textarea name="body" class="box" required><?php echo e($writing->body); ?></textarea>

            <button class="lebar-100 mt-3 primer">
                Simpan Perubahan
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/admin/copywriting.blade.php ENDPATH**/ ?>