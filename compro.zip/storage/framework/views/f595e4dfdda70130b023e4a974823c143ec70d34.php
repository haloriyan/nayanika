<div style="padding: 20px;background: #ecf0f1;">
    <div style="background: #fff;border: 1px solid #fff;border-radius: 6px;padding: 25px;">
        <p>Isian dari form website NayaNika</p>
        <div style="margin-top: 20px;">Nama : <?php echo e($user['name']); ?></div>
        <div style="margin-top: 20px;">Email : <?php echo e($user['email']); ?></div>
        <div style="margin-top: 20px;">Telepon : <?php echo e($user['phone']); ?></div>
        <div style="margin-top: 20px;">Kota : <?php echo e($user['city']); ?></div>
        <div style="margin-top: 20px;">Perusahaan : <?php echo e($user['company']); ?></div>
        <div style="margin-top: 20px;">Industri : <?php echo e($user['industry_field']); ?></div>

        <h3>Service :</h3>
        <div><?php echo e($user['services']); ?></div>
        <h3>Ala Carte :</h3>
        <div><?php echo e($user['alacartes']); ?></div>
    </div>
</div><?php /**PATH /home/haloriyan/project/compro/resources/views/emails/OrderService.blade.php ENDPATH**/ ?>