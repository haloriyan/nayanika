<div class="tinggi-160"></div>
<section class="cta rata-tengah">
    <a href="<?php echo e(route('user.service')); ?>">
        <button>Let's get to work</button>
    </a>
</section><?php /**PATH /home/haloriyan/project/compro/resources/views///partials/CTA.blade.php ENDPATH**/ ?>