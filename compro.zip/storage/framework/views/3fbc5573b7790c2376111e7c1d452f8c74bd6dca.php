<?php $__env->startSection('title', "Services"); ?>

<?php $__env->startSection('header.action'); ?>
<button class="primer rounded-none" onclick="munculPopup('#addService')">
    <i class="fas fa-plus mr-1"></i> Baru
</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-putih rounded bayangan-5 smallPadding">
    <div class="wrap">
        <?php if($message != ""): ?>
            <div class="bg-hijau-transparan rounded p-2 mb-3">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>

        <?php if($services->count() == 0): ?>
            <h3 class="rata-tengah">Tidak ada data</h3>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Nama Service</th>
                        <th>Kategori</th>
                        <th class="lebar-20"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($service->name); ?></td>
                            <td><?php echo e($service->category->name); ?></td>
                            <td>
                                <span class="bg-hijau-transparan rounded p-1 pl-2 pr-2 pointer" onclick="edit('<?php echo e($service); ?>')">
                                    <i class="fas fa-edit"></i>
                                </span>
                                <span class="bg-merah-transparan rounded p-1 pl-2 pr-2 pointer ml-1" onclick="hapus('<?php echo e($service); ?>')">
                                    <i class="fas fa-trash"></i>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<div class="bg"></div>
<div class="popupWrapper" id="addService">
    <div class="popup">
        <div class="wrap">
            <h3>Tambah Service Baru
                <i class="fas fa-times ke-kanan pointer" onclick="hilangPopup('#addService')"></i>
            </h3>
            <form action="<?php echo e(route('admin.service.store')); ?>" method="POST" class="wrap super">
                <?php echo e(csrf_field()); ?>

                <div class="mt-2">Kategori :</div>
                <select name="category_id" id="category" class="box" required>
                    <option value="">-- PILIH KATEGORI --</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <div class="mt-2">Nama Layanan :</div>
                <input type="text" class="box" name="name" id="name" required>

                <button class="lebar-100 mt-3 primer">Tambahkan</button>
            </form>
        </div>
    </div>
</div>

<div class="popupWrapper" id="editService">
    <div class="popup">
        <div class="wrap">
            <h3>Edit Service
                <i class="fas fa-times ke-kanan pointer" onclick="hilangPopup('#editService')"></i>
            </h3>
            <form action="<?php echo e(route('admin.service.update')); ?>" method="POST" class="wrap super">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="id" name="id">
                <div class="mt-2">Kategori :</div>
                <select name="category_id" id="category_id" class="box" required>
                    <option value="">-- PILIH KATEGORI --</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <div class="mt-2">Nama Layanan :</div>
                <input type="text" class="box" name="name" id="name" required>

                <button class="lebar-100 mt-3 primer">Tambahkan</button>
            </form>
        </div>
    </div>
</div>

<div class="popupWrapper" id="deleteService">
    <div class="popup">
        <div class="wrap">
            <h3>Hapus Service
                <i class="fas fa-times ke-kanan pointer" onclick="hilangPopup('#deleteService')"></i>
            </h3>
            <form action="<?php echo e(route('admin.service.delete')); ?>" method="POST" class="wrap super">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" id="id">
                Yakin ingin menghapus service <b id="name"></b> ?

                <button class="lebar-100 mt-3 primer">Ya, hapus</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    const hapus = data => {
        data = JSON.parse(data);
        munculPopup("#deleteService");
        select("#deleteService #id").value = data.id;
        select("#deleteService #name").innerText = data.name;
    }

    const edit = data => {
        data = JSON.parse(data);
        munculPopup("#editService");
        select("#editService #id").value = data.id;
        select("#editService #name").value = data.name;
        select(`#editService #category_id option[value='${data.category_id}']`).selected = true;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/admin/service.blade.php ENDPATH**/ ?>