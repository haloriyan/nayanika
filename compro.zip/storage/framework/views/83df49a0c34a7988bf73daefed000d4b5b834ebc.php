<?php $__env->startSection('title', "Login Admin"); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.login')); ?>" method="POST">
    <div class="wrap super">
        <?php if($errors->count() != 0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-merah-transparan rounded p-2 mb-3">
                    <?php echo e($err); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if($message != ""): ?>
            <div class="bg-hijau-transparan rounded p-2 mb-3">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        
        <input type="hidden" name="r" value="<?php echo e($request->r); ?>">

        <?php echo e(csrf_field()); ?>

        <div class="mt-2">Email :</div>
        <input type="email" class="box" name="email" required>
        <div class="mt-2">Password :</div>
        <input type="password" class="box" name="password" required>

        <button class="lebar-100 mt-3 primer">Login</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/admin/login.blade.php ENDPATH**/ ?>