<?php $__env->startSection('title', "Get in Touch - "); ?>

<?php $__env->startSection('head.dependencies'); ?>
<style>
    .tinggi-160 {
        display: none;
    }
    section.footer .customContent h3 {
        display: inline-block;
        font-size: 80px;
        margin-top: -120px;
        letter-spacing: 3px;
        line-height: 20px;
        background-color: #111;
        padding-right: 45px;
        position: relative;
        top: -65px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="tinggi-100"></div>
<?php echo $__env->make('./partials/Footer', ['customContent' => "<h3>LET'S</h3><br />
<h3>GET TO WORK <i class='fas fa-external-link-alt ml-2'></i></h3>"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/contact.blade.php ENDPATH**/ ?>