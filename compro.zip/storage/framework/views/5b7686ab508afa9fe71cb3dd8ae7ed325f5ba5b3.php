<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(env('APP_NAME')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fa/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <?php echo $__env->yieldContent('head.dependencies'); ?>
</head>
<body>
    
<?php
    $currentRoute = Route::current();
    $routeParameters = json_decode(json_encode($currentRoute->parameters), FALSE);
    $prefix = $currentRoute->getPrefix();
    $prefixes = explode("/", $prefix);
?>

<div class="main-navigation">
    <a href="<?php echo e(route('admin.profile')); ?>">
        <div class="header smallPadding rata-tengah">
            <div class="wrap super">
                <div class="icon mb-1"><?php echo e($myData->initial); ?></div>
                <h2><?php echo e($myData->name); ?></h2>
            </div>
        </div>
    </a>
    <ul>
        <a href="<?php echo e(route('admin.dashboard')); ?>">
            <li class="<?php echo e($currentRoute->uri == 'admin/dashboard' ? 'active' : ''); ?>">
                <div class="icon"><i class="fas fa-home"></i></div>
                <div class="text">Dashboard</div>
            </li>
        </a>
        <a href="#">
            <li class="<?php echo e($prefixes[0] == 'admin' && $prefixes[1] == 'master' ? 'active' : ''); ?>">
                <div class="icon"><i class="fas fa-box"></i></div>
                <div class="text">Master
                    <i class="fas fa-angle-down"></i>
                </div>
                <ul>
                    <a href="<?php echo e(route('admin.category')); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'admin.category' ? 'active' : ''); ?>">
                            <div class="icon"><i class="fas fa-tags"></i></div>
                            <div class="text">Kategori</div>
                        </li>
                    </a>
                    <a href="<?php echo e(route('admin.service')); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'admin.service' ? 'active' : ''); ?>">
                            <div class="icon"><i class="fas fa-cogs"></i></div>
                            <div class="text">Services</div>
                        </li>
                    </a>
                    <a href="<?php echo e(route('admin.portfolio')); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'admin.portfolio' || (array_key_exists(2, $prefixes) && $prefixes[2] == 'portfolio') ? 'active' : ''); ?>">
                            <div class="icon"><i class="fas fa-briefcase"></i></div>
                            <div class="text">Portfolio</div>
                        </li>
                    </a>
                    <a href="<?php echo e(route('admin.admin')); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'admin.admin' || (array_key_exists(2, $prefixes) && $prefixes[2] == 'admin') ? 'active' : ''); ?>">
                            <div class="icon"><i class="fas fa-users"></i></div>
                            <div class="text">Admin</div>
                        </li>
                    </a>
                </ul>
            </li>
        </a>
        <a href="#">
            <li class="<?php echo e($prefixes[0] == 'admin' && $prefixes[1] == 'copywriting' ? 'active' : ''); ?>">
                <div class="icon"><i class="fas fa-edit"></i></div>
                <div class="text">Copywriting
                    <i class="fas fa-angle-down"></i>
                </div>
                <ul>
                    <?php $__currentLoopData = $myData->copywritings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $writing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.copywriting.edit', $writing->item_code)); ?>">
                            <li class="<?php echo e($prefixes[1] == "copywriting" && $routeParameters->code == $writing->item_code ? 'active' : ''); ?>">
                                <div class="text"><?php echo e(ucwords($writing->item_code)); ?></div>
                            </li>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        </a>
        
        <a href="<?php echo e(route('admin.logout')); ?>">
            <li class="<?php echo e($currentRoute->uri == 'admin/logout' ? 'active' : ''); ?>">
                <div class="icon"><i class="fas fa-sign-out-alt"></i></div>
                <div class="text">Logout</div>
            </li>
        </a>
    </ul>
</div>

<header class="main">
    <h1><?php echo $__env->yieldContent('header.beforeTitle'); ?> <?php echo $__env->yieldContent('title'); ?></h1>
    <div class="action">
        <?php echo $__env->yieldContent('header.action'); ?>
    </div>
</header>

<div class="content">
    <?php echo $__env->yieldContent('content'); ?>
    <div class="tinggi-70"></div>
</div>

<script src="<?php echo e(asset('js/base.js')); ?>"></script>
<?php echo $__env->yieldContent('javascript'); ?>

</body>
</html><?php /**PATH /home/haloriyan/project/compro/resources/views/layouts/admin.blade.php ENDPATH**/ ?>