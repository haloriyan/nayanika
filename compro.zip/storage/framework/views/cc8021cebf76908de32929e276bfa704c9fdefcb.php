<?php $__env->startSection('content'); ?>
<div class="aboveTheFold">
    <h2>TURNING YOUR IDEAS INTO MAGNIFICENT VISUALS</h2>
    <div class="desktop">
        <section class="footer">
            <div class="bagi bagi-3">
                <div>#DoMagnificent</div>
            </div>
            <div class="bagi bagi-3">
                <pre><?php echo $writings['footer 1']; ?></pre>
            </div>
            <div class="bagi bagi-3">
                <pre><?php echo $writings['footer 2']; ?></pre>
            </div>
        </section>
    </div>
    <div class="mobile">
        <section class="footer">
            <div class="bagi bagi-2">
                <div class="lebar-90">
                    <div>#DoMagnificent</div>
                    <pre><?php echo $writings['footer 1']; ?></pre>
                </div>
            </div>
            <div class="bagi bagi-2 rata-kanan">
                <pre><?php echo $writings['footer 2']; ?></pre>
            </div>
        </section>
    </div>
</div>

<div class="tinggi-160"></div>
<?php echo $__env->make('partials/OurValue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="tinggi-160"></div>
<section class="portfolio">
    <h3>OUR WORK</h3>
    <div id="items">
        <div id="loadPortfolio"></div>
        
        <br />
        <div class="item"></div>
        <div class="item">
            <h4 class="pointer garis-bawah" id="loadMore" onclick="loadMore()">
                Load More
            </h4>
            <h4 class="pointer d-none garis-bawah" id="toPortfolio">
                <a href="<?php echo e(route('user.portfolio')); ?>">
                    All Work <i class="fas fa-external-link-alt ml-2"></i>
                </a>
            </h4>
        </div>
    </div>
</section>

<div class="tinggi-160"></div>
<section class="service">
    <div class="bagi bagi-2">
        <h3>WHAT WE DO</h3>
        <p class="lebar-80"><?php echo e($writings['service']); ?></p>
    </div>
    <div class="bagi bagi-2" id="items">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 class="mt-0"><?php echo e($category->name); ?></h3>
            <?php $__currentLoopData = $category->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bagi bagi-4">
                    <div class="wrap">
                        <div class="containerList squarize" style="height: 150px;">
                            <div class="item"><?php echo e($service->name); ?></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('user.service')); ?>">
                <div class="bagi bagi-4">
                    <div class="wrap">
                        <div class="containerList" style="height: 150px;">
                            <div class="item">SHOW MORE <br /> <i class="fas fa-external-link-alt"></i></div>
                        </div>
                    </div>
                </div>
            </a>
            <div class="tinggi-40"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<?php echo $__env->make('./partials/CTA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('./partials/Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    let toLoad = 5;
    let loadedDataId = [];

    const loadPortfolio = () => {
        let req = post("<?php echo e(route('api.portfolio.load')); ?>", {
            count: toLoad
        })
        .then(res => {
            let datas = res.datas;
            if (datas.length < toLoad) {
                console.log(datas);
                select("#loadMore").classList.add('d-none');
                select("#toPortfolio").classList.remove('d-none');
            }
            datas.forEach(portfolio => {
                if (!inArray(portfolio.id, loadedDataId)) {
                    createElement({
                        el: "div",
                        attributes: [
                            ['class', 'portfolio-item']
                        ],
                        html: `<div class="bagi bagi-2">
        <div class="wrap ml-0">
            <a href="<?php echo e(route('user.portfolio.detail')); ?>/${portfolio.id}">
                <div class="cover squarize rectangle rounded" bg-image="<?php echo e(asset('storage/portfolio_images')); ?>/${portfolio.featured_image}"></div>
            </a>
        </div>
    </div>
    <div class="bagi bagi-2 detail">
        <div class="ml-0 p-4">
            <a href="<?php echo e(route('user.portfolio.detail')); ?>/${portfolio.id}">
                <h3>${portfolio.title}
                    <i class="fas fa-external-link-alt ke-kanan teks-kecil mt-1"></i>
                </h3>
                <p>${portfolio.description}</p>
            </a>
            <div id="categoriesArea${portfolio.id}"></div>
        </div>
    </div>
    <br />
    <hr size="1" color="#fff" />`,
                        createTo: '#loadPortfolio'
                    });

                    let categories = portfolio.categories.split(",");
                    categories.forEach(category => {
                        createElement({
                            el: 'a',
                            attributes: [
                                ['href', `<?php echo e(route('user.portfolio')); ?>?category=${category}`]
                            ],
                            html: `<div class="category-item">${category}</div>`,
                            createTo: `#categoriesArea${portfolio.id}`
                        });
                    });
                }
                loadedDataId.push(portfolio.id);
            });
            bindDivWithImage();
            squarize();
            toggleLightMode(1);
        });
    }
    loadPortfolio();

    const loadMore = () => {
        toLoad += 5;
        loadPortfolio();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/index.blade.php ENDPATH**/ ?>