<?php $__env->startSection('title', $portfolio->title); ?>

<?php $__env->startSection('head.dependencies'); ?>
<style>
    .aboveTheFold h2 {
        padding-bottom: 40px;
        border-bottom: 2px solid #fff;
    }
    @media (max-width: 480px) {
        .main-cover {
            height: 250px;
        }
        .cover { height: 120px; }
        .bagi.bagi-2.desktop {
            display: block;
            margin: 0;
            width: 100%;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="aboveTheFold">
    <h2><?php echo e($portfolio->title); ?></h2>
</div>

<div class="main-cover squarize rectangle rounded mt-4" bg-image="<?php echo e(asset('storage/portfolio_images/'.$portfolio->featured_image)); ?>"></div>

<div class="tinggi-60"></div>
<div class="bagi bagi-2 desktop">
    <h3 class="mt-0">ABOUT</h3>
</div>
<div class="bagi bagi-2 desktop">
    <div class="teks-besar"><?php echo e($portfolio->description); ?></div>
</div>

<div class="tinggi-60"></div>

<?php if(isset($portfolio->images[0])): ?>
<div class="bagi bagi-2">
    <div class="wrap">
        <div class="cover squarize rectangle rounded" bg-image="<?php echo e(asset('storage/portfolio_images/'.$portfolio->images[0]->filename)); ?>"></div>
    </div>
</div>
<?php endif; ?>

<?php if(isset($portfolio->images[1])): ?>
<div class="bagi bagi-2">
    <div class="wrap">
        <div class="cover squarize rectangle rounded" bg-image="<?php echo e(asset('storage/portfolio_images/'.$portfolio->images[1]->filename)); ?>"></div>
    </div>
</div>
<?php endif; ?>

<div class="tinggi-60"></div>
<div class="bagi bagi-2 desktop">
    <h3 class="mt-0">PROBLEM & SOLVE</h3>
</div>
<div class="bagi bagi-2 desktop">
    <div class="teks-besar"><?php echo e($portfolio->task); ?></div>
</div>

<div class="tinggi-60"></div>

<div class="gallery">
    <?php
        $images = json_decode(json_encode($portfolio->images));
        array_splice($images, 0, 2);
    ?>
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
            <div class="wrap">
                <img src="<?php echo e(asset('storage/portfolio_images/'.$image->filename)); ?>" class="lebar-100 rounded">
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo $__env->make('./partials/CTA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('./partials/Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/masonry.js')); ?>"></script>
<script>
    let generateMasonry = new Masonry({
        container: '.gallery',
        items: '.gallery .item',
        dividedBy: 2
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haloriyan/project/compro/resources/views/portfolioDetail.blade.php ENDPATH**/ ?>